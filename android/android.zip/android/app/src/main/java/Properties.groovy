class Properties {
}
